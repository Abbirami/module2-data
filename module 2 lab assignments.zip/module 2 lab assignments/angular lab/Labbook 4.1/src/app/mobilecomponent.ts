import {Component,OnInit} from '@angular/core';
import {Book} from './mobile';
import {BookService} from './app.mobileservice';
@Component({
    selector:'book-app',
    templateUrl:'./mobile.html',
    providers:[BookService]
})
export class BookComponent implements OnInit{
    bookData:Book[];
    click:boolean;
    
constructor(private _mobileservice:BookService){
        }
        ngOnInit(){
        this._mobileservice.getAllMobileDetail().
        subscribe((data:Book[])=>this.bookData=data);
        }
        
//     delete(data){
//         for(var i=0;i<this.bookData.length;i++)
//                 {
//                     if(this.bookData[i].id==data.id)
//                     {
//                         this.bookData.splice(i,1);
//                     }
//                 }
//         }
    
// idSort(){
//     this.bookData.sort(function(a,b)
//     {
//         return a.id - b.id;
//     });
            
// }

// titleSort()
// {
//     this.bookData.sort(function(a,b)
// {
//     if(a.title < b.title)
//     return -1;
//     else
//     return 1;
// })
// }

// yearSort()
// {
//     this.bookData.sort(function(a,b)
//     {
//         return a.year - b.year;
//     });
    
// }
// authorSort()
// {
//     this.bookData.sort(function(a,b)
// {
//     if(a.author < b.author)
//     return -1;
//     else
//     return 1;
// })
// }


        
}

