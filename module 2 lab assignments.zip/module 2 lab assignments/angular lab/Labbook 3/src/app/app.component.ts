import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.main.html',
  //styleUrls: ['./app.component.css']
//template: '<mob-app></mob-app>'
})
export class AppComponent {
  }
